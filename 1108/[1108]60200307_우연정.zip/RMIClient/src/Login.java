import java.rmi.Naming;
import java.rmi.RemoteException;

public class Login implements ILogin{ //진짜 로그인과 연결된 stub
	
private ILogin login;
public Login(){
	//url: ip-port-object
	
	try {
		String url = "rmi://localhost/login";
		this.login = (ILogin) Naming.lookup(url);
	} catch (Exception e) {
		System.err.println("Client exception: " + e.getMessage());
		e.printStackTrace();
	}
} //예외 처리는 뷰에서 해야한다.

public String login(){
	String result = null;

	try {
		result = login.login();
		System.out.println("Message from the server: " + result);
	} catch (RemoteException e) {
		System.err.println("Client exception: " + e.getMessage());
		e.printStackTrace();
	}
	return result;
}
}