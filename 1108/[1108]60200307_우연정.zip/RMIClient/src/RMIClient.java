import java.rmi.Naming;

public class RMIClient { //인터페이스를 사용해서 스텁을 만든다.
	public static void main(String[] args) {
		ILogin login = new Login();
	}
}
