

public class RMIServer {
	public static void main(String[] args) {
		LoginSkeleton login = new LoginSkeleton();
	}
}