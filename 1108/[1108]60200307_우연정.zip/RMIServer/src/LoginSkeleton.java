import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;

public class LoginSkeleton implements ILogin{
	public LoginSkeleton() {
	try {
		// remote object 만들기
		ILogin login = new Login();
		
		// 
		LocateRegistry.createRegistry(1099);
		
		//등록, 객체 이름 노출
		Naming.rebind("login", login);
			
		System.out.println("Server is ready.");
		
	}catch(Exception e) {
		System.err.println("Server exception: " + e.getMessage());
		e.printStackTrace();
	}
}

	@Override
	public String login() throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}
}
