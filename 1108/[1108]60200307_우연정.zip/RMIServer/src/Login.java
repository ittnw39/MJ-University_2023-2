import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

class Login extends UnicastRemoteObject implements ILogin {
	
	private static final long serialVersionUID = 1L;
	
	protected Login() throws RemoteException {
		super();
	}
	
	public String login() throws RemoteException{
		return "Hello from the server!";
	}
}
