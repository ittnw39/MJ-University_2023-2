
public class CLogin implements IControl{
 public CLogin() {
	 
 }
 
 public String getUserInfo(){
	 String userInfo = "userInfo";
	 return userInfo;
	 }
}
