
public class Control implements IControl{
 public Control() {
	 
 }
 
 public String getUserInfo(){
	 String userInfo = "userInfo";
	 return userInfo;
	 }
}
