import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class HelloServer extends UnicastRemoteObject implements Hello {
    protected HelloServer() throws RemoteException {
        super();
    }

    public void printHelloWorld() {
        System.out.println("Hello World from Server!");
    }
}