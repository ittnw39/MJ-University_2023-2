import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class Server {

	public static void main(String[] args) {
		 try {
	            // RMI registry를 현재 머신에서 기본 포트로 시작
	            LocateRegistry.createRegistry(1099);

	            // 서비스 등록
	            HelloServer helloService = new HelloServer();
	            Naming.rebind("HelloService", helloService);

	            System.out.println("Server Ready!");
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	}

}
