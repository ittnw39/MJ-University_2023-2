import java.rmi.Naming;

public class Client {

	public static void main(String[] args) {
		 try {
	            // 서버에 등록된 서비스 참조 가져오기
	            Hello helloService = (Hello) Naming.lookup("rmi://localhost/HelloService");
	            
	            // 메서드 호출
	            helloService.printHelloWorld();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	}

}
