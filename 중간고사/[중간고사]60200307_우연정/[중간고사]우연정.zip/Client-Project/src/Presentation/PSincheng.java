package Presentation;

import java.io.UnsupportedEncodingException;
import java.util.Scanner;
import java.util.Vector;

import Stub.SinchengStub;
import valueObject.VLecture;
import valueObject.VUserInfo;

public class PSincheng {
	private PLectureBasket pSinchengBasket;
	private SinchengStub sinchengStub;

	public PSincheng() {
		this.pSinchengBasket = new PLectureBasket();
		this.sinchengStub = new SinchengStub();
	}

	public void goSincheng(VLecture vLecture, VUserInfo vuserinfo, Scanner keyboard) throws UnsupportedEncodingException {
		loadSincheng(vuserinfo.getUserID(), vuserinfo); // 파일에서 수강신청 내용을 읽어옵니다.
		
	    if (pSinchengBasket.jungbok(vLecture)) {
	        System.out.println("이미 수강신청한 강좌입니다.");
	    } else if (pSinchengBasket.contains(vLecture.getCode())) {
	        System.out.println("이미 수강신청한 강좌입니다.");
	    } else {
	    	int newTotalCredits = vLecture.getCredit() + vuserinfo.getTotalCredits(); // 신청할 강좌의 학점과 기존 신청한 강좌들의 학점 합계
            int maxHakjum = vuserinfo.getMaxHakjum(); // 최대 수강 가능 학점

            if (newTotalCredits > maxHakjum) {
                System.out.println("수강 가능한 학점을 초과하였습니다... >>" );
                System.out.println("수강 가능 학점: " + (maxHakjum));
                System.out.println("현재 신청한 학점: " + vuserinfo.getTotalCredits());
                return;
            }
	        
	        pSinchengBasket.add(vLecture);
	        writeSinchengToServer(vuserinfo.getUserID(), "Sincheng", vLecture);
	        System.out.println("수강 신청 되었습니다. >> ");
	    }
	    showSincheng(keyboard, vuserinfo.getUserID(), vuserinfo);
	}
	
	
	
	public void loadSincheng(String userID, VUserInfo vuserinfo) {
		pSinchengBasket.clear();
	    
	    Vector<VLecture> vLectureVector = sinchengStub.loadSinchengFromServer(userID);
	    int totalCredits = 0;

	    for (VLecture vLecture : vLectureVector) {
	        pSinchengBasket.add(vLecture);
	        totalCredits += vLecture.getCredit();
	    }

	    vuserinfo.setTotalCredits(totalCredits);
	}

	private void writeSinchengToServer(String userID, String fileType, VLecture vLecture) {
		Vector<VLecture> result = sinchengStub.writeSinchengLectureToServer(userID, fileType, vLecture);
		if (result.isEmpty()) {
	        System.out.println("강좌 정보 쓰기 실패");
	    }
	}
	
	public void showSincheng(Scanner keyboard,  String userID, VUserInfo vuserinfo) throws UnsupportedEncodingException {
		pSinchengBasket.show();
		
		System.out.println("1.삭제 2.메뉴 9.종료");

        String aCode = keyboard.next();
        int bCode = Integer.parseInt(aCode);

        switch (bCode) {
            case 1: //삭제 기능으로
                deleteLecture(keyboard, userID);
                break;
            case 2: //메뉴로
            	 PSugangsincheng pSugangsincheng = new PSugangsincheng();
                 pSugangsincheng.run(vuserinfo, keyboard);
            	return;
            case 9:
                System.exit(0);
                break;
            default:
                break;
        }
      
	}
	

	private void deleteLecture(Scanner keyboard, String userID) {
		while (true) {
            System.out.print("삭제할 강좌 코드를 입력하세요: ");
            int lectureCode = keyboard.nextInt();
            if (pSinchengBasket.contains(lectureCode)) {
            	
                pSinchengBasket.remove(lectureCode);
                deleteLectureFromServer(userID, lectureCode);
                
                System.out.println("강좌가 삭제되었습니다. >> " + lectureCode);
                
                System.out.println("신청 목록 >>");
                pSinchengBasket.show();
                break;
            } else {
                System.out.println("해당 강좌 코드가 존재하지 않습니다. 다시 입력하세요.");
            }
        }       
	}

	private void deleteLectureFromServer(String userID, int lectureCode) {
		Vector<VLecture> result = sinchengStub.deleteSinchengLectureFromServer(userID, lectureCode);
		if (result.isEmpty()) {
		        System.out.println("강좌 정보 삭제 실패.");
		    }
	}
}
