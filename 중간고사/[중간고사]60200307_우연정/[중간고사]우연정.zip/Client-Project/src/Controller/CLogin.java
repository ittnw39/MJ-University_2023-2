package Controller;
import Stub.LoginStub;
import valueObject.VLogin;
import valueObject.VUserInfo;

public class CLogin { //v를 위한 전용 워커.

	 private LoginStub stub;

	    public CLogin() {
	        this.stub = new LoginStub();
	    }

	    public VUserInfo login(VLogin vlogin) {
	        return stub.requestLogin(vlogin);
	    }

}
