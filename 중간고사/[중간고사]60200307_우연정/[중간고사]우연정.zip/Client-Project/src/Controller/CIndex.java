package Controller;

import java.io.UnsupportedEncodingException;
import java.util.Vector;

import Stub.IndexStub;
import valueObject.VIndex;

public class CIndex {

	private IndexStub indexStub;

    public CIndex() {
        this.indexStub = new IndexStub();
    }

    public Vector<VIndex> getVIndexVector(String fileName) throws UnsupportedEncodingException {
        return this.indexStub.requestIndexVector(fileName);
    }
}
