package Stub;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Vector;

import valueObject.VLecture;

public class SinchengStub {
	private final String SERVER_ADDRESS = "localhost";
    private final int SERVER_PORT = 12346;
    
    public Vector<VLecture> loadSinchengFromServer(String userID) {
        Vector<VLecture> vLectureVector = new Vector<>();

        try (Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"))) {

            out.println("CLecture");
            out.println("loadSinchengFromServer");
            out.println(userID);

            String response;
            while ((response = in.readLine()) != null && !response.isEmpty()) {
                String[] parts = response.split(" ");
                VLecture vLecture = new VLecture();
                vLecture.setCode(Integer.parseInt(parts[0]));
                vLecture.setName(parts[1]);
                vLecture.setProfessor(parts[2]);
                vLecture.setCredit(Integer.parseInt(parts[3]));
                vLecture.setTime(parts[4]);
                
                vLectureVector.add(vLecture);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return vLectureVector;
    }
    
	 public Vector<VLecture> writeSinchengLectureToServer(String userID, String fileType, VLecture vLecture) {
    	 Vector<VLecture> vLectureVector = new Vector<>();
    	
    	try (Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"))) {

            // 서버에 과목 정보 요청
            out.println("CLecture");
            out.println("writeSinchengLectureToServer");
            out.println(userID);
            out.println(fileType);
            out.println(vLecture.toString());

            String response;
            while ((response = in.readLine()) != null && !response.isEmpty()) {
                String[] parts = response.split(" ");
                if (parts.length == 5) {  // 모든 부분이 존재하는지 확인
                    VLecture vLecture2 = new VLecture();
                    
                    vLecture2.setCode(Integer.parseInt(parts[0].trim()));  // code 값 설정
                    vLecture2.setName(parts[1].trim());  // name 값 설정
                    vLecture2.setProfessor(parts[2].trim());  // professor 값 설정
                    vLecture2.setCredit(Integer.parseInt(parts[3].trim()));  // credit 값 설정
                    vLecture2.setTime(parts[4].trim());  // time 값 설정
                    
                    vLectureVector.add(vLecture2);
                } else {
                    System.out.println("서버의 응답 형식이 잘못되었습니다: " + response);
            }
            }
           } catch (Exception e) {
            e.printStackTrace();
        }
        return vLectureVector;
        }
    
    public Vector<VLecture> deleteSinchengLectureFromServer(String userID, int lectureCode) {
    	 Vector<VLecture> vLectureVector = new Vector<>();
    	
        try (Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"))) {

            out.println("CLecture");
            out.println("deleteSinchengLectureFromServer");
            out.println(userID);
            out.println(lectureCode);

            String response;
            while ((response = in.readLine()) != null && !response.isEmpty()) {
                String[] parts = response.split(" ");
                if (parts.length == 5) {  // 모든 부분이 존재하는지 확인
                    VLecture vLecture = new VLecture();
                    
                    vLecture.setCode(Integer.parseInt(parts[0].trim()));  // code 값 설정
                    vLecture.setName(parts[1].trim());  // name 값 설정
                    vLecture.setProfessor(parts[2].trim());  // professor 값 설정
                    vLecture.setCredit(Integer.parseInt(parts[3].trim()));  // credit 값 설정
                    vLecture.setTime(parts[4].trim());  // time 값 설정
                    
                    vLectureVector.add(vLecture);
                } else {
                    System.out.println("서버의 응답 형식이 잘못되었습니다: " + response);
            }
            }
           } catch (Exception e) {
            e.printStackTrace();
        }
        return vLectureVector;
        }
}
