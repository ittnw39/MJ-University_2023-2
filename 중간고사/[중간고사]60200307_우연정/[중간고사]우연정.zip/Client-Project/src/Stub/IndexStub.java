package Stub;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Vector;

import valueObject.VIndex;

public class IndexStub {
	private final String SERVER_ADDRESS = "localhost";
    private final int SERVER_PORT = 12346;

    public Vector<VIndex> requestIndexVector(String fileName) {
        Vector<VIndex> vIndexVector = new Vector<>();

        try (Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"))) {

            // 서버에 강좌 정보 요청
            out.println("CIndex");
            out.println("getVIndexVector");
            out.println(fileName);

            // 서버의 응답을 받아 Vector<VIndex>로 변환
            String response;
                while ((response = in.readLine()) != null && !response.isEmpty()) {
                    String[] parts = response.split(","); // 콤마를 기준으로 데이터 분할
                    if (parts.length == 3) {  // code, name, filename 세 부분이 모두 있는지 확인
                        VIndex vIndex = new VIndex();
                        vIndex.setCode(Integer.parseInt(parts[0].trim()));  // code 값 설정
                        vIndex.setName(parts[1].trim());  // name 값 설정
                        vIndex.setFilename(parts[2].trim());  // filename 값 설정
                        vIndexVector.add(vIndex);
            }else {
                System.out.println("Invalid response format from server: " + response);
            }
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
        return vIndexVector;
    }
}
