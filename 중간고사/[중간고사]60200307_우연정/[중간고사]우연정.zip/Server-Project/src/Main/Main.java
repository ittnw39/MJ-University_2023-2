package Main;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import Skeleton.Skeleton;

public class Main{
	
	private static final int SERVER_PORT = 12346; // 클라이언트와 동일한 포트 번호 사용

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(SERVER_PORT)) {
            System.out.println("서버 시작, 포트: " + SERVER_PORT);
            while (true) {
                Socket clientSocket = serverSocket.accept(); // 클라이언트 연결 대기
                System.out.println("클라이언트 연결됨: " + clientSocket.getInetAddress());

                // 연결 처리를 위한 스레드 시작
                Skeleton clientHandler = new Skeleton(clientSocket);
                clientHandler.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
