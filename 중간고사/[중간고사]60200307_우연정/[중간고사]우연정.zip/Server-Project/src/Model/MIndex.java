package Model;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;
import java.util.Vector;

import valueObject.VIndex;

public class MIndex {
	public Vector<VIndex> getVIndexVector(String fileName) throws UnsupportedEncodingException {
		Vector<VIndex> vIndexVector =null;
		
		try {
			Scanner file = new Scanner(new InputStreamReader(new FileInputStream("data/" + fileName + ".txt"), "UTF-8"));
			 vIndexVector = new Vector<VIndex>();
			while(file.hasNext()) {
				VIndex vIndex = new VIndex();
				vIndex.load(file);
				vIndexVector.add(vIndex);
			}
			file.close();
			
			
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}
		return vIndexVector;
	}
}
