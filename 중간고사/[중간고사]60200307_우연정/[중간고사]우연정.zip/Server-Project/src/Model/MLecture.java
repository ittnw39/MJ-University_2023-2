package Model;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;
import java.util.Vector;

import valueObject.VLecture;

public class MLecture {
	public Vector<VLecture> getVLectureVector(String fileName) throws UnsupportedEncodingException {
		Vector<VLecture> vLectureVector =null;
		try {
			Scanner file = new Scanner(new InputStreamReader(new FileInputStream("data/" + fileName + ".txt"), "UTF-8"));
			 vLectureVector = new Vector<VLecture>();
			while(file.hasNext()) {
				VLecture vLecture = new VLecture();
				vLecture.load(file);
				vLectureVector.add(vLecture);
			}
			file.close();
			
			
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}
		return vLectureVector;
	}
}
