package Controller;

import java.io.UnsupportedEncodingException;
import java.util.Vector;

import Model.MBasket;
import Model.MLecture;
import Model.MSincheng;
import valueObject.VLecture;

public class CLecture {
    private MLecture mLecture;
    private MSincheng mSincheng;
    private MBasket mBasket;

    public CLecture() {
        this.mLecture = new MLecture();
        this.mSincheng = new MSincheng();
        this.mBasket = new MBasket();
    }

    public Vector<VLecture> getVLectureVector(String fileName) throws UnsupportedEncodingException {
    	System.out.println("ServerMethod 호출됨");
        return this.mLecture.getVLectureVector(fileName);
    }

    public Vector<VLecture> writeSinchengLectureToServer(String userID, String fileType, VLecture vLecture) throws UnsupportedEncodingException {
    	System.out.println("ServerMethod 호출됨");
    	return this.mSincheng.writeSinchengLectureToServer(userID, fileType, vLecture);
    }

    public Vector<VLecture> deleteSinchengLectureFromServer(String userID, int lectureCode) throws UnsupportedEncodingException {
    	System.out.println("ServerMethod 호출됨");
    	return this.mSincheng.deleteSinchengLectureFromServer(userID, lectureCode);
    }

    public Vector<VLecture> loadSinchengFromServer(String userID) throws UnsupportedEncodingException {
    	System.out.println("ServerMethod 호출됨");
    	return this.mSincheng.getVLectureVector(userID);
    }

    public Vector<VLecture> writeBasketLectureToServer(String userID, String fileType, VLecture vLecture) throws UnsupportedEncodingException {
    	System.out.println("ServerMethod 호출됨");
    	return this.mBasket.writeBasketLectureToServer(userID, fileType, vLecture);
    }

    public Vector<VLecture> deleteBasketLectureFromServer(String userID, int lectureCode) throws UnsupportedEncodingException {
    	System.out.println("ServerMethod 호출됨");
        return this.mBasket.deleteBasketLectureFromServer(userID, lectureCode);
    }

    public Vector<VLecture> loadBasketFromServer(String userID) throws UnsupportedEncodingException {
    	System.out.println("ServerMethod 호출됨");
        return this.mBasket.getVLectureVector(userID);
    }
}
