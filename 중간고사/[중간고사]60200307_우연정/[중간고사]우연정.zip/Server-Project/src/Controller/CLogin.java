package Controller;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;

import Model.MAccount;
import valueObject.VLogin;
import valueObject.VUserInfo;

public class CLogin { //v를 위한 전용 워커.

	public VUserInfo login(VLogin vlogin) throws FileNotFoundException, UnsupportedEncodingException {
		// TODO Auto-generated method stub
		MAccount maccount = new MAccount();
		VUserInfo vuserinfo = maccount.login(vlogin);
		return vuserinfo;
	}

}
