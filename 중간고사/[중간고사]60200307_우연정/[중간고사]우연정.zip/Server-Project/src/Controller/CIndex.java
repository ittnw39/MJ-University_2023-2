package Controller;

import java.io.UnsupportedEncodingException;
import java.util.Vector;

import Model.MIndex;
import valueObject.VIndex;

public class CIndex {

	private MIndex mIndex;
	
	public CIndex() {
		this.mIndex = new MIndex();
	}
	
	public Vector<VIndex> getVIndexVector(String fileName) throws UnsupportedEncodingException {
		Vector<VIndex> vIndexVector = this.mIndex.getVIndexVector(fileName);
		return vIndexVector;
	}
}
