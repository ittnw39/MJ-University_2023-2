package Skeleton;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Vector;

import Controller.CIndex;
import Controller.CLecture;
import Controller.CLogin;
import valueObject.VIndex;
import valueObject.VLecture;
import valueObject.VLogin;
import valueObject.VUserInfo;

public class Skeleton extends Thread {
	    private Socket clientSocket;
	    private BufferedReader in;
	    private PrintWriter out;

	    public Skeleton(Socket clientSocket) {
	        this.clientSocket = clientSocket;
	        try {
	            this.in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
	            this.out = new PrintWriter(clientSocket.getOutputStream(), true);
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	    @Override
	    public void run() {
	        try {
	            String className = in.readLine();
	            String methodName = in.readLine();

	            switch (className) {
	                case "CLogin":
	                    handleCLogin(methodName);
	                    break;
	                case "CIndex":
	                	handleCIndex(methodName);
	                	break;
	                case "CLecture":
	                	handleCLecture(methodName);
	                	break;
	                // 다른 클래스들에 대한 스켈레톤 처리도 여기에 추가
	            }

	        } catch (IOException e) {
	            e.printStackTrace();
	        } finally {
	            try {
	                clientSocket.close();
	            } catch (IOException e) {
	                e.printStackTrace();
	            }
	        }
	    }

	    private void handleCLecture(String methodName) throws IOException {
	    	 switch (methodName) {
	         case "getVLectureVector":
	             String fileName = in.readLine();

	             // 모델을 사용하여 실제 강의 정보를 가져오고 결과를 반환
	             Vector<VLecture> vLectureVector = new CLecture().getVLectureVector(fileName);

	             // 반환된 Vector를 out을 사용하여 클라이언트에게 전송.
	             for (VLecture vLecture : vLectureVector) {
	            	 
	                 out.println(vLecture.toString());
	             }
	             break;
	             
	         case "loadSinchengFromServer": //됨
	        	 String userIDSincheng = in.readLine();
	             Vector<VLecture> loadSinchengVLectureVector = new CLecture().loadSinchengFromServer(userIDSincheng);
	             for (VLecture vLecture : loadSinchengVLectureVector) {
	                 out.println(vLecture.toString());
	             }
	             break;
	        	 
	         case "loadBasketFromServer": //됨
	             String userID = in.readLine();
	             Vector<VLecture> basketVLectureVector = new CLecture().loadBasketFromServer(userID);
	             for (VLecture vLecture : basketVLectureVector) {
	                 out.println(vLecture.toString());
	             }
	             break;
	             
	         case "writeBasketLectureToServer": //됨
	        	 String userIDForBasket = in.readLine();
	             String fileTypeForBasket = in.readLine();
	             VLecture vLectureForBasket = new VLecture();
	             
	             String inputLine = in.readLine();
	             String[] parts = inputLine.split(" "); // 공백을 기준으로 문자열 분리

	             vLectureForBasket.setCode(Integer.parseInt(parts[0]));
	             vLectureForBasket.setName(parts[1]);
	             vLectureForBasket.setProfessor(parts[2]);
	             vLectureForBasket.setCredit(Integer.parseInt(parts[3]));
	             vLectureForBasket.setTime(parts[4]);
	             
	             Vector<VLecture> basketWriteVLectureVector = new CLecture().writeBasketLectureToServer(userIDForBasket, fileTypeForBasket, vLectureForBasket);
	             for (VLecture vLecture : basketWriteVLectureVector) {
	                 out.println(vLecture.toString());
	             }
	             break;
	             
	         case "deleteBasketLectureFromServer": //됨
	             String userIDForDeleteBasket = in.readLine();
	             int lectureCodeForDeleteBasket = Integer.parseInt(in.readLine());
	             Vector<VLecture> deleteBasketVLectureVector = new CLecture().deleteBasketLectureFromServer(userIDForDeleteBasket, lectureCodeForDeleteBasket);
	             for (VLecture vLecture : deleteBasketVLectureVector) {
	                 out.println(vLecture.toString());
	             }
	             break;
	             
	         case "writeSinchengLectureToServer": //됨
	             String userIDForSincheng = in.readLine();
	             String fileTypeForSincheng = in.readLine();
	             VLecture vLectureForSincheng = new VLecture();
	             
	             String inputLine2 = in.readLine();
	             String[] parts2 = inputLine2.split(" "); // 공백을 기준으로 문자열 분리

	             vLectureForSincheng.setCode(Integer.parseInt(parts2[0]));
	             vLectureForSincheng.setName(parts2[1]);
	             vLectureForSincheng.setProfessor(parts2[2]);
	             vLectureForSincheng.setCredit(Integer.parseInt(parts2[3]));
	             vLectureForSincheng.setTime(parts2[4]);

	             Vector<VLecture> sinchengVLectureVector = new CLecture().writeSinchengLectureToServer(userIDForSincheng, fileTypeForSincheng, vLectureForSincheng);
	             for (VLecture vLecture : sinchengVLectureVector) {
	                 out.println(vLecture.toString());
	             }
	             break;
	             
	         case "deleteSinchengLectureFromServer": //됨
	             String userIDForDeleteSincheng = in.readLine();
	             int lectureCodeForDeleteSincheng = Integer.parseInt(in.readLine());
	             Vector<VLecture> deleteSinchengVLectureVector = new CLecture().deleteSinchengLectureFromServer(userIDForDeleteSincheng, lectureCodeForDeleteSincheng);
	             for (VLecture vLecture : deleteSinchengVLectureVector) {
	                 out.println(vLecture.toString());
	             }
	             break;	 
	    }
		}

		private void handleCIndex(String methodName) throws IOException {
	    	switch (methodName) {
	        case "getVIndexVector":
	            String fileName = in.readLine();

	            //모델을 사용하여 실제 정보를 가져와 결과를 반환하는 코드
	            Vector<VIndex> vIndexVector = new CIndex().getVIndexVector(fileName);

	            // 반환된 Vector를 out을 사용하여 클라이언트에게 전송.
	            for (VIndex vIndex : vIndexVector) {
	            	 String index = vIndex.getCode() + "," + vIndex.getName() + "," + vIndex.getFilename();
	                 out.println(index);
	             }
	            break;
	    }
		}

		private void handleCLogin(String methodName) throws IOException {
			System.out.println("Login request received.");
			switch (methodName) {
	            case "login":
	                String credentials = in.readLine();
	                String[] parts = credentials.split(",");
	                String userId = parts[0];
	                String userPw = parts[1];

	                //모델을 사용하여 로그인 처리를 하고 결과를 반환
	                VUserInfo userInfo = new CLogin().login(new VLogin(userId, userPw));

	                if (userInfo != null) {
	                    out.println(userInfo.getUserID() + "," + userInfo.getName() + "," + userInfo.getMaxHakjum());
	                } else {
	                    out.println("로그인에 실패하였습니다.");
	                }
	                break;
	    }
	    }
}
