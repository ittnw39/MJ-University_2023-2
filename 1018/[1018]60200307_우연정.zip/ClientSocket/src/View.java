
public class View { //화면
	
	private IControl control; //진짜 컨트롤은 서버에 있다. 컨트롤 중에서 스텁이다. 대신하는 가짜.
	
	
	public View() {
		this.control = new Control();
	}
	
	public void showUserInfo() {
		String userInfo = this.control.getUserInfo();
		System.out.println(userInfo);
	}
}
