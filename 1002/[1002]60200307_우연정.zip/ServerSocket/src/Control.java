
public class Control {
 public Control() {
	 
 }
 
 public String getUserInfo(){
	 String userInfo = "userInfo";
	 return userInfo;
	 }
}
