package Interface;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

public interface ICLecture {

    void getVLectureVector(BufferedReader in, PrintWriter out) throws UnsupportedEncodingException, IOException;
    void loadSinchengFromServer(BufferedReader in, PrintWriter out) throws UnsupportedEncodingException, IOException;
    void loadBasketFromServer(BufferedReader in, PrintWriter out) throws UnsupportedEncodingException, IOException;
    void writeBasketLectureToServer(BufferedReader in, PrintWriter oute) throws UnsupportedEncodingException, IOException;
    void deleteBasketLectureFromServer(BufferedReader in, PrintWriter out) throws UnsupportedEncodingException, IOException;

}
