package Interface;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

public interface ICIndex {
	void getVIndexVector(BufferedReader in, PrintWriter out) throws UnsupportedEncodingException, IOException;
}
