package Interface;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

public interface ICLogin {
	void login(BufferedReader in, PrintWriter out) throws FileNotFoundException, UnsupportedEncodingException, IOException;
}
