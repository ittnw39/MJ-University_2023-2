package Skeleton;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.Socket;

import Controller.CIndex;
import Controller.CLecture;
import Controller.CLogin;

public class Skeleton extends Thread {
	    private Socket clientSocket; //클라이언트 소켓설정
	    private BufferedReader in;
	    private PrintWriter out;

	    public Skeleton(Socket clientSocket) {
	        this.clientSocket = clientSocket;
	        try {
	            this.in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
	            this.out = new PrintWriter(clientSocket.getOutputStream(), true);
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	    @Override
	    public void run() {//쓰레드 상속받음
	        try {//자바 리플렉션 사용
	            String className = in.readLine();//클래스 이름 받아오기
	            String methodName = in.readLine();//메소드 이름 받아오기
	            
	            Object controller = getController(className);
	            Method method = controller.getClass().getMethod(methodName, BufferedReader.class, PrintWriter.class);
	            method.invoke(controller, in, out);
	            
	        } catch (IOException | NoSuchMethodException | SecurityException | IllegalAccessException | InvocationTargetException e) {
	        	Throwable cause = e.getCause();
	            cause.printStackTrace();
			} finally {
	            try {
	                clientSocket.close();
	            } catch (IOException e) {
	                e.printStackTrace();
	            }
	        }
	    }

	    private Object getController(String className) { //클래스 이름에 따라 컨트롤러 만듦.
	    	  switch (className) {
	          case "CLogin":
	              return new CLogin();
	          case "CIndex":
	              return new CIndex();
	          case "CLecture":
	              return new CLecture();
	          
	          default:
	              throw new IllegalArgumentException("Not class name: " + className);
	      }
		}
	    }

