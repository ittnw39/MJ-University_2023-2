package Model;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;
import java.util.Vector;

import valueObject.VLecture;

public class MBasket {
	
	public Vector<VLecture> getVLectureVector(String filename) throws UnsupportedEncodingException {
		Vector<VLecture> vLectureVector =null;
		try {
			Scanner file = new Scanner(new InputStreamReader(new FileInputStream("Basket/"+ filename + "Basket.txt"), "UTF-8"));
			 vLectureVector = new Vector<VLecture>();
			while(file.hasNext()) {
				VLecture vLecture = new VLecture();
				vLecture.load(file);
				vLectureVector.add(vLecture);
			}
			file.close();
			
			
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}

		return vLectureVector;
	}

	public Vector<VLecture> writeBasketLectureToServer(String userID, String fileType, VLecture vLecture) throws UnsupportedEncodingException {
		 try {
	            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("Basket/" + userID + "Basket.txt", true), "UTF-8"));
	            String lectureData = vLecture.toString();
	            bw.write(lectureData);
	            bw.newLine();
	            bw.close();
	        } catch(IOException e) {
	            e.printStackTrace();
	        }
	        return getVLectureVector(userID);
	}

	public Vector<VLecture> deleteBasketLectureFromServer(String userID, int lectureCode) throws UnsupportedEncodingException {
		 Vector<VLecture> currentLectures = getVLectureVector(userID);

	        if (currentLectures == null) {
	            return null;
	        }

	        Vector<VLecture> updatedLectures = new Vector<VLecture>();
	        for (VLecture vLecture : currentLectures) {
	            if (vLecture.getCode() != lectureCode) {
	                updatedLectures.add(vLecture);
	            }
	        }

	        try {
	            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("Basket/" + userID + "Basket.txt", false), "UTF-8"));
	            for (VLecture vLecture : updatedLectures) {
	                String lectureData = vLecture.toString();
	                bw.write(lectureData);
	                bw.newLine();
	            }
	            bw.close();
	        } catch(IOException e) {
	            e.printStackTrace();
	        }
	        return updatedLectures;
	        
	    }
}
