package Controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;

import Interface.ICIndex;
import Model.MIndex;
import valueObject.VIndex;

public class CIndex implements ICIndex {

	private MIndex mIndex;
	
	public CIndex() {
		this.mIndex = new MIndex();
	}
	
	public void getVIndexVector(BufferedReader in, PrintWriter out) throws IOException {
		String fileName = in.readLine();
		Vector<VIndex> vIndexVector = this.mIndex.getVIndexVector(fileName);
		
		for (VIndex vIndex : vIndexVector) {
            out.println(vIndex.toString());
        }
	}
}
