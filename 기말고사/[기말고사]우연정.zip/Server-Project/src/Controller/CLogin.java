package Controller;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

import Interface.ICLogin;
import Model.MAccount;
import valueObject.VLogin;
import valueObject.VUserInfo;

public class CLogin implements ICLogin { //v를 위한 전용 워커.

	public void login(BufferedReader in, PrintWriter out) throws IOException, UnsupportedEncodingException {
        String credentials = in.readLine();
        String[] parts = credentials.split(",");
        VLogin vLogin = new VLogin(parts[0], parts[1]);

        MAccount mAccount = new MAccount();
        VUserInfo vUserInfo = mAccount.login(vLogin);

        if (vUserInfo != null) {
            out.println(vUserInfo.getUserID() + "," + vUserInfo.getName() + "," + vUserInfo.getMaxHakjum());
        } else {
            out.println("Login failed");
        }
    }
}
