package Controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;

import Interface.ICLecture;
import Model.MBasket;
import Model.MLecture;
import Model.MSincheng;
import valueObject.VLecture;

public class CLecture implements ICLecture {
    private MLecture mLecture;
    private MSincheng mSincheng;
    private MBasket mBasket;

    public CLecture() {
        this.mLecture = new MLecture();
        this.mSincheng = new MSincheng();
        this.mBasket = new MBasket();
    }

    public void getVLectureVector(BufferedReader in, PrintWriter out) throws IOException {
    	String fileName = in.readLine();
    	Vector<VLecture> vLectureVector = this.mLecture.getVLectureVector(fileName);
        for (VLecture vLecture : vLectureVector) {
            out.println(vLecture.toString());
        }
    }

    public void writeSinchengLectureToServer(BufferedReader in, PrintWriter out) throws IOException {
    	String userID = in.readLine();
        String fileType = in.readLine();
        VLecture vLecture = readVLecture(in); // VLecture 객체를 읽는 별도의 메소드 필요

        Vector<VLecture> result = this.mSincheng.writeSinchengLectureToServer(userID, fileType, vLecture);
        for (VLecture lecture : result) {
            out.println(lecture.toString());
        }
    }

    public void deleteSinchengLectureFromServer(BufferedReader in, PrintWriter out) throws IOException {
    	String userID = in.readLine();
        int lectureCode = Integer.parseInt(in.readLine());

        Vector<VLecture> result = this.mSincheng.deleteSinchengLectureFromServer(userID, lectureCode);
        for (VLecture lecture : result) {
            out.println(lecture.toString());
        }
    }

    public void loadSinchengFromServer(BufferedReader in, PrintWriter out) throws IOException {
    	String userID = in.readLine();
        Vector<VLecture> vLectureVector = this.mSincheng.getVLectureVector(userID);
        for (VLecture vLecture : vLectureVector) {
            out.println(vLecture.toString());
        }
    }

    public void writeBasketLectureToServer(BufferedReader in, PrintWriter out) throws IOException {
    	String userID = in.readLine();
        String fileType = in.readLine();
        VLecture vLecture = readVLecture(in); // VLecture 객체를 읽는 별도의 메소드 필요

        Vector<VLecture> result = this.mBasket.writeBasketLectureToServer(userID, fileType, vLecture);
        for (VLecture lecture : result) {
            out.println(lecture.toString());
        }
    }

    private VLecture readVLecture(BufferedReader in) throws IOException {
        // 클라이언트로부터 VLecture에 필요한 데이터를 읽는다.
        String line = in.readLine();
        String[] parts = line.split(" "); // 가정: 클라이언트가 쉼표로 구분된 데이터를 보냄

        // 각 파트는 VLecture의 필드에 해당한다고 가정
        int code = Integer.parseInt(parts[0]);
        String name = parts[1];
        String professor = parts[2];
        int credit = Integer.parseInt(parts[3]);
        String time = parts[4];

        // VLecture 객체 생성 및 데이터 설정
        VLecture vLecture = new VLecture();
        vLecture.setCode(code);
        vLecture.setName(name);
        vLecture.setProfessor(professor);
        vLecture.setCredit(credit);
        vLecture.setTime(time);

        return vLecture;
    }


	public void deleteBasketLectureFromServer(BufferedReader in, PrintWriter out) throws IOException {
    	 String userID = in.readLine();
         int lectureCode = Integer.parseInt(in.readLine());

         Vector<VLecture> result = this.mBasket.deleteBasketLectureFromServer(userID, lectureCode);
         for (VLecture lecture : result) {
             out.println(lecture.toString());
         }
    }

    public void loadBasketFromServer(BufferedReader in, PrintWriter out) throws IOException {
    	 String userID = in.readLine();
         Vector<VLecture> vLectureVector = this.mBasket.getVLectureVector(userID);
         for (VLecture vLecture : vLectureVector) {
             out.println(vLecture.toString());
         }
}
}
