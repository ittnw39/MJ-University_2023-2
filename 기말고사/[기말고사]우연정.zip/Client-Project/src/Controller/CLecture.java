package Controller;

import java.io.UnsupportedEncodingException;
import java.util.Vector;

import Stub.BasketStub;
import Stub.LectureStub;
import Stub.SinchengStub;
import valueObject.VLecture;

public class CLecture {
	 private LectureStub lectureStub;
	 private SinchengStub sinchengStub;
	 private BasketStub basketStub;

	    public CLecture() {
	        this.lectureStub = new LectureStub();
	    }

	    public Vector<VLecture> getVLectureVector(String fileName) throws UnsupportedEncodingException {
	        return this.lectureStub.requestLectureVector(fileName);
	    }
	    public Vector<VLecture> writeSinchengLectureToServer(String userID,String fileType, VLecture vLecture) throws UnsupportedEncodingException {
	        return this.sinchengStub.writeSinchengLectureToServer(userID, fileType, vLecture);
	    }
	    public Vector<VLecture> deleteSinchengLectureFromServer(String userID, int lectureCode) throws UnsupportedEncodingException {
	        return this.sinchengStub.deleteSinchengLectureFromServer(userID, lectureCode);
	    }
	    public Vector<VLecture> loadSinchengFromServer(String userID) throws UnsupportedEncodingException {
	        return this.sinchengStub.loadSinchengFromServer(userID);
	    }
	    public Vector<VLecture> writeBasketLectureToServer(String userID, String fileType, VLecture addedLecture) throws UnsupportedEncodingException {
	        return this.basketStub.writeBasketLectureToServer(userID, fileType, addedLecture);
	    }
	    public Vector<VLecture> deleteBasketLectureFromServer(String userID, int lectureCode) throws UnsupportedEncodingException {
	        return this.basketStub.deleteBasketLectureFromServer(userID, lectureCode);
	    }
	    public Vector<VLecture> loadBasketFromServer(String userID) throws UnsupportedEncodingException {
	        return this.basketStub.loadBasketFromServer(userID);
	    }
}
