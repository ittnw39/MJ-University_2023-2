package LMS;
import java.awt.BorderLayout;

import javax.swing.JPanel;

public class LMainPanel extends JPanel {
	private static final long serialVersionUID = 1L;

	//자식들
	private LDirectory directory;
	//미리담기 패널=
	//수강신청 패널=
	//컨트롤 패널-버튼
	private LLRButtonPanel directoryToMiridamgi;
	private LTable miridamgi;//디렉토리와 테이블을 이니셜라이즈
	
	public LMainPanel() { //속성 정의, 자식만들기
//		this.setBackground(Color.blue);
		this.directory = new LDirectory();
		this.add(this.directory);
		this.add(this.directory, BorderLayout.NORTH);

		this.directoryToMiridamgi = new LLRButtonPanel();
        this.add(this.directoryToMiridamgi);	
        // LTable 인스턴스를 생성.
        this.miridamgi = new LTable();
        // LTable을 메인 패널에 추가.
        this.add(this.miridamgi, BorderLayout.CENTER);
        
       
	}


	public void initialize() {// new/association 나누기
		//자식들의 association만들기
		//액션 핸들러를 만들 때에는 버튼의 경우 항상 자신의 상위에 만들것. - 액션핸들러를 어소시에이션을 가지고 있는 해당 부모 밑에 집어넣을 것.
		this.directoryToMiridamgi.associate(this.directory, this.miridamgi); //속성
		
		
		
		this.directory.initialize();
		this.directoryToMiridamgi.initialize();
		this.miridamgi.initailize();
		
	}
}
