package LMS;
import javax.swing.JMenuBar;

public class LMenuBar extends JMenuBar {
	private static final long serialVersionUID = 1L;
	
	private LFileMenu fileMenu; //1.자식 만들기
	public LMenuBar() {
		this.fileMenu = new LFileMenu();
		this.add(this.fileMenu); //2. 자식 등록하기
	}
	public void initialize() {
		// TODO Auto-generated method stub
		
	}

}
