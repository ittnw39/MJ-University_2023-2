package LMS;
import java.util.Vector;

import javax.swing.JPanel;
import javax.swing.JTable;

public class LTable extends JPanel { //테이블을 직접 상속받아도 상관없다.
    private static final long serialVersionUID = 1L;
    
    private JTable table;

    public LTable() {
        // JTable 인스턴스를 생성하고 초기 데이터와 컬럼 이름을 설정합니다.
       String[] columns = {"강좌아이디", "강좌이름", "강사", "학점", "시간"};
       Object[][] data = new Object[] []{
            {"강좌아이디", "강좌이름", "강사", "학점", "시간"},
            {"강좌아이디", "강좌이름", "강사", "학점", "시간"},
            {"강좌아이디", "강좌이름", "강사", "학점", "시간"}
            // 추가 데이터 행...
        };
       this.table = new JTable(data, columns);
       this.add(this.table);
        // 테이블 데이터와 컬럼 이름을 설정합니다.
       

    }

	public void initailize() {
		
	}

	public void addLectures(Vector<Lecture> lectures) {
	
	}

	public Vector<Lecture> getLectures() {
		
		return null;
	}

}
