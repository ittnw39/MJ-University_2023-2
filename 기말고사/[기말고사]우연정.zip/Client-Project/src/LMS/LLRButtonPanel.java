package LMS;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JPanel;

public class LLRButtonPanel extends JPanel{ //이벤트 핸들러는 여기에 있어야한다.
	private static final long serialVersionUID = 1L;
	
	//자식 component
	private JButton lButton;
	private JButton rButton;
	
	//친구 associations
	private LDirectory directory;
	private LTable table;
	
	public LLRButtonPanel (){
		ActionHandler actionHandler = new ActionHandler();

		this.lButton = new JButton(">>");//왼>오
		this.lButton.addActionListener(actionHandler);
		this.add(lButton);
		
		this.rButton = new JButton("<<");//오>왼
		this.rButton.addActionListener(actionHandler);
		this.add(rButton);
		
		//버튼에 액션 핸들러를 달아야함.
		//버튼 패널은 디텍토리와 미리담기 혹은 디렉토리와 수강신청
	}
	
	public void associate(LDirectory directory, LTable table) {//친구 연결
		this.directory = directory;
		this.table = table;// 미리담기 혹은 수강신청이 된다. 테이블 하나로 두개를 쓸 수 있다.
	}
	
	public void initialize() {
		
		
	}
	
	private void moveDirectoryToTable() {//업무분리, 디렉토리에서 테이블로
		Vector<Lecture> lectures = this.directory.getLectures();//디렉토리에서 multiple selection이 될수있기 때문에 벡터사용
			this.table.addLectures(lectures);
		}
	
	private void moveTableToDirectory() {//테이블에서 디렉토리로 옮기기
		Vector<Lecture> lectures = this.table.getLectures();//디렉토리에서 multiple selection이 될수있기 때문에 벡터사용
		this.directory.addLectures(lectures);
		}
	
	private class ActionHandler implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {//센서
			if (e.getSource()==lButton) {//디렉토리에서 미리담기로
				moveDirectoryToTable();
			}else if(e.getSource()==rButton){
				moveTableToDirectory();//신호 제어만 하기
			}		
		}
	}
}
