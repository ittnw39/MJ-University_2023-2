package LMS;
import java.io.UnsupportedEncodingException;
import java.util.Vector;

import javax.swing.JPanel;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

import Controller.CIndex;
import valueObject.VIndex;

public class LDirectory extends JPanel { //현재의 디렉토리의 하위 디렉토리를 보여줌
	private static final long serialVersionUID = 1L;
	private JTree tree;
    private DefaultTreeModel treeModel;
    private CIndex cIndex;
    
    public LDirectory() {
    	this.cIndex = new CIndex();
        DefaultMutableTreeNode rootNode = new DefaultMutableTreeNode("root");
        this.treeModel = new DefaultTreeModel(rootNode);
        this.tree = new JTree(treeModel);
        this.add(tree);

        // 루트 노드를 기반으로 리프 노드를 생성
        loadChildNodes(rootNode, "root");

    }

    private void loadChildNodes(DefaultMutableTreeNode node, String fileName) {
    	try {
            // 서버로부터 데이터 요청
            Vector<VIndex> vIndices = cIndex.getVIndexVector(fileName);
            if (vIndices != null) {
                for (VIndex vIndex : vIndices) {
                    DefaultMutableTreeNode childNode = new DefaultMutableTreeNode(vIndex.getName());
                    node.add(childNode);
                    // 하위 파일 이름을 이용하여 노드 추가 - recursion
                    loadChildNodes(childNode, vIndex.getFilename());
                }
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        treeModel.reload(node); // 트리 모델 업데이트
    }

	public void initialize() {
	}

	public Vector<Lecture> getLectures() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public void addLectures(Vector<Lecture> lectures) {
		// TODO Auto-generated method stub
		
	}



}
