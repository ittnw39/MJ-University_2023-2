package Stub;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import valueObject.VLogin;
import valueObject.VUserInfo;

public class LoginStub {
	private final String SERVER_ADDRESS = "localhost";
    private final int SERVER_PORT = 12346;
    		
    public VUserInfo requestLogin(VLogin vlogin) {
        try (Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"))) {

            // 서버에 로그인 요청 정보 전송
            out.println("CLogin");
            out.println("login");
            out.println(vlogin.getUserID() + "," + vlogin.getUserPW());

            // 서버의 응답을 받음
            String response = in.readLine();

            // 응답을 VUserInfo 객체로 변환
            VUserInfo userInfo = new VUserInfo();
            
            
            String[] parts = response.split(",");
            if(parts.length == 3) {
                userInfo.setUserID(parts[0]);
                userInfo.setName(parts[1]);
                userInfo.setMaxHakjum(Integer.parseInt(parts[2]));
            System.out.println(userInfo);
            }
            return userInfo;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
