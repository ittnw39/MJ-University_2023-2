package Presentation;

import java.io.UnsupportedEncodingException;
import java.util.Scanner;
import java.util.Vector;

import Stub.BasketStub;
import Stub.SinchengStub;
import valueObject.VLecture;
import valueObject.VUserInfo;

public class PMiridamgi {
	private PLectureBasket pMiridamgiBasket;
	private PSincheng pSincheng;
	 private BasketStub basketStub;
	 public PMiridamgi() {
		this.pMiridamgiBasket = new PLectureBasket();
		this.pSincheng = new PSincheng();
		this.basketStub = new BasketStub();
		new SinchengStub();
	}
	
	public void goBasket(VUserInfo vuserinfo, VLecture vLecture, Scanner keyboard) throws UnsupportedEncodingException {
		
		loadBasket(vuserinfo.getUserID(), vuserinfo); // 파일에서 수강신청 내용을 읽어옴

	    if (pMiridamgiBasket.jungbok(vLecture)) {
	        System.out.println("이미 미리담기한 강좌입니다.");
	    } else if (pMiridamgiBasket.contains(vLecture.getCode())) {
	        System.out.println("이미 미리담기한 강좌입니다.");
	    } else {
	    	int newTotalCredits = vLecture.getCredit() + vuserinfo.getTotalCredits(); // 미리담기할 강좌의 학점과 장바구니 속 학점의 합
            int maxHakjum = vuserinfo.getMaxHakjum() + 6; // 최대 미리담기 가능한 학점

            if (newTotalCredits > maxHakjum) {
                System.out.println("미리담기 가능한 학점을 초과하였습니다... >>");
                System.out.println("장바구니 최대 학점: " + (maxHakjum));
                System.out.println("현재 담긴 학점: " + vuserinfo.getTotalCredits());
                return;
            }

	        pMiridamgiBasket.add(vLecture);
	        writeToFile(vuserinfo.getUserID(), "Basket", vLecture);
	        System.out.println("미리 담기 되었습니다. >> " + vLecture);
	    }
	    
		   while (true) {
        System.out.println("1.신청 2.삭제 3.메뉴 9. 종료");

		String aCode = keyboard.next();
		int bCode = Integer.parseInt(aCode);

		switch (bCode) {
		case 1: // 그대로 수강신청하기
			if (pMiridamgiBasket.contains(vLecture.getCode())) {
                pSincheng.goSincheng(vLecture, vuserinfo, keyboard);
            } else {
                System.out.println("해당 강좌 코드가 존재하지 않습니다. 다시 입력하세요.");
            }
            break;
		case 2:
			deleteFromBasket(vuserinfo.getUserID(), vLecture.getCode());
			System.out.println("강좌가 장바구니에서 삭제되었습니다. >> " + vLecture.getCode());
			vLecture = null;
			break;
		case 3: // 강좌선택메뉴로
			vLecture = null;
            return;
		case 9:
			System.exit(0);
			break;
		default:
			break;
		}
        }
	}

	public void loadBasket(String userID, VUserInfo vuserinfo) {//파일에서 읽어오는 부분
		 pMiridamgiBasket.clear();
		
		   Vector<VLecture> vLectureVector = basketStub.loadBasketFromServer(userID);
	        int totalCredits = 0;
	        for (VLecture vLecture : vLectureVector) {
	            pMiridamgiBasket.add(vLecture);
	            totalCredits += vLecture.getCredit();
	        }
	        vuserinfo.setTotalCredits(totalCredits);
	    }
	   
	
	
	public void writeToFile(String userID, String fileType, VLecture addedLecture) {
		Vector<VLecture> result = basketStub.writeBasketLectureToServer(userID, fileType, addedLecture);
		if (result.isEmpty()) {
            System.out.println("강좌정보 서버로 전송 실패.");
        }
	}

	public void showBasket(Scanner keyboard, String userID, VLecture vLecture, VUserInfo vuserinfo) throws UnsupportedEncodingException {
		pMiridamgiBasket.show();
		
		while (true) {
			System.out.println("1.신청 2.삭제 3.메뉴 9.종료");

			String aCode = keyboard.next();
			int bCode = Integer.parseInt(aCode);

			switch (bCode) {
				case 1: // 그대로 수강신청하기
					System.out.print("신청할 강좌 코드를 입력하세요: ");
	                int lectureCode = keyboard.nextInt();
	                VLecture selectedLecture = pMiridamgiBasket.get(lectureCode);
	                if (selectedLecture != null) {
	                    pSincheng.goSincheng(selectedLecture, vuserinfo, keyboard);
	                } else {
	                    System.out.println("해당 강좌 코드가 존재하지 않습니다. 다시 입력하세요.");
	                }
	                break;
				case 2: // 장바구니에서 삭제
					System.out.print("삭제할 강좌 코드를 입력하세요: ");
					int deleteCode = keyboard.nextInt();
					if (pMiridamgiBasket.contains(deleteCode)) {
						pMiridamgiBasket.remove(deleteCode);
						deleteFromBasket(userID, deleteCode);
						System.out.println("강좌가 삭제되었습니다. >> " + deleteCode);
						System.out.println("장바구니 목록 >>");
						pMiridamgiBasket.show();
					} else {
						System.out.println("해당 강좌 코드가 존재하지 않습니다. 다시 입력하세요.");
					}
					break;
				case 3: // 메뉴로	
	                return;
				case 9:
					System.exit(0);
					break;
				default:
					break;
			}
		}
	}
	
		private void deleteFromBasket(String userID, int lectureCode) {
			Vector<VLecture> result = basketStub.deleteBasketLectureFromServer(userID, lectureCode);
			if (result.isEmpty()) {
	            System.out.println("강좌정보 삭제하기 실패.");
			}
		}
	
	}

