import java.awt.Color;
import java.io.File;

import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class LDirectory extends JPanel {
	private static final long serialVersionUID = 1L;

	public LDirectory() {
		File rootDirectory = new File("."); //현재 디렉토리를 루트로 설정
		DefaultMutableTreeNode rootNode = createDirectoryTree(rootDirectory);
		JTree tree = new JTree(rootNode);
		this.add(tree);
		
//	    this.setBackground(Color.LIGHT_GRAY);
//
//        // 리스트에 들어갈 항목들
//        String[] items = {"용인", "서울"};
//
//        // JList 생성
//        JList<String> list = new JList<>(items);
//
//        // 스크롤 가능하도록 JScrollPane에 JList 추가
//        JScrollPane scrollPane = new JScrollPane(list);
//
//        // JScrollPane를 패널에 추가
//        this.add(scrollPane);
	}
	public void initialize() {
	}
	
	private static DefaultMutableTreeNode createDirectoryTree(File dir) {
		DefaultMutableTreeNode node = new DefaultMutableTreeNode(dir.getName());
		if(dir.isDirectory()) {
			File[] files = dir.listFiles();
			if(files != null) {
				for(File file : files) {
					node.add(createDirectoryTree(file));
				}
			}
		}
		return node;
	}



}
