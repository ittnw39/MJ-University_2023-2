import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Arrays;
import java.util.HashMap;

public class Skeleton { //항상 대기, 루핑돌기를 하고 있다.
	private final int port;
	HashMap<String, Object> objectMap;  //맴 테이블, 디렉토리, 네이밍 서비스
	private ServerSocket serverSocket;
	
	public Skeleton() {
		this.port = 12345;
		this.objectMap = new HashMap<String, Object>();
		this.objectMap.put("cLogin", new CLogin());
	}
	
	public void process() {
		 //서버 소켓을 만드려면 포트번호가 필요함 -> 바인딩()
		//서버 소켓은 자신의 네트워크 카드와 포트 넘버를 할당한다.
		//파일도 일종의 통신의 매거니즘, 시간적 통신 / 네트워크는 공간적 통신
		try {//서버 소켓 생성
			serverSocket = new ServerSocket(port);
			System.out.println("서버가 시작되었습니다. 포트: " + port);
			
			while(true) { // 서버 무한 루프
				//클라이언트 연결 대기
				Socket clientSocket = serverSocket.accept(); //접속할 때까지 기다리기.
				System.out.println("클라이언트가 연결되었습니다.: " + clientSocket.getInetAddress());
				
				Session session = new Session(clientSocket, objectMap); //세션 만들기
				session.process();
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public class Session{
		private Socket clientSocket;
		private HashMap<String,Object> objectMap;
		
		public Session(Socket clientSocket, HashMap<String, Object> objectMap) {
			this.clientSocket = clientSocket;
			this.objectMap = objectMap;
			//파라미터는 주소이다. 대부분 힙의 주소.
		}

		public void process() throws ClassNotFoundException {
		    //여기서부터 세션이 담당한다.
		    try {            
		        //클라이언트와 데이터를 주고받기 위한 입력 및 출력 스트림 생성
		        ObjectOutputStream oos = new ObjectOutputStream(clientSocket.getOutputStream());
		        ObjectInputStream ois = new ObjectInputStream(clientSocket.getInputStream());

		        //클라이언트로부터 메시지 받기
		        String objectName = (String) ois.readObject();
		        String methodName = (String) ois.readObject();
		        
		        // 인자 타입과 인자 값이 있다면 읽기
		        Class<?>[] argTypes = (Class<?>[]) ois.readObject();
		        Object[] args = (Object[]) ois.readObject();

		        // 객체 찾기
		        Object object = objectMap.get(objectName);

		        System.out.println("클라이언트로부터 받은 메시지: " + objectName + methodName + Arrays.toString(args));

		        //클라이언트에게 응답 보내기 null string
		        String result = null;
		        if (object != null) {
		        	// 메소드를 찾을 때 argTypes가 비어 있거나 null이라면 빈 클래스 배열을 사용
		            argTypes = new Class<?>[0]; // 빈 배열로 초기화
		            Method method = object.getClass().getMethod(methodName);
		            result = (String) method.invoke(object); // args 없이 메소드 호출
		        }
		        oos.writeObject(result);
		        oos.flush();

		        // 클라이언트 소켓 닫기
		        clientSocket.close();
		        System.out.println("클라이언트와 연결 종료: " + clientSocket.getInetAddress());
		    } catch (IOException | NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
		        e.printStackTrace();
		    }
		}
	}
}
