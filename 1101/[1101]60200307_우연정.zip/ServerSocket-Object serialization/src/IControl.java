
public interface IControl {
	public String getUserInfo();
}
