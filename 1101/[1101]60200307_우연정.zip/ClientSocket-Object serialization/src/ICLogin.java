
public interface ICLogin {
	public String getUserInfo();
}
