
public class View { //화면
	
	private ICLogin cLogin; //진짜 컨트롤은 서버에 있다. 컨트롤 중에서 스텁이다. 대신하는 가짜.
	
	
	public View() {
		this.cLogin = new CLogin();
	}
	
	public void showUserInfo() {
		String userInfo = this.cLogin.getUserInfo();//리모트인지 로컬인지 구별못함.
		System.out.println(userInfo);
	}
}
