
public class CLogin extends Stub implements ICLogin{

	public CLogin() {
		super("localhost", 12345);
	}

	public String getUserInfo() { //런타임의 진짜 이름
		String result = this.request("cLogin","getUserInfo", "");
		return result;
	}
}

