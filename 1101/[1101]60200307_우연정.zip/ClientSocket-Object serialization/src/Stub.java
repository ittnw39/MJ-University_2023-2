import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.io.Serializable;

public class Stub {
    private String serverIP;
    private int serverPort;

    public Stub(String serverIP, int serverPort) {
        this.serverIP = serverIP;
        this.serverPort = serverPort;
    }

    public String request(String objectName, String methodName, Serializable... args) {
        Socket socket = null;
        ObjectOutputStream out = null;
        ObjectInputStream in = null;
        String response = null;


        try {
            // 서버에 연결
            socket = new Socket(serverIP, serverPort);
            System.out.println("스텁이 스켈레톤에 연결되었습니다.");

            // 서버로 객체를 전송하기 위한 출력 스트림 생성
            out = new ObjectOutputStream(socket.getOutputStream());

         // 서버로 메서드 이름과 객체를 전송
         out.writeObject(objectName);
         out.writeObject(methodName);

         // 매개변수 타입과 값이 모두 있다면 순서대로 전송
         if (args != null && args.length > 0) {
             Class<?>[] argTypes = new Class<?>[args.length];
             for (int i = 0; i < args.length; i++) {
                 argTypes[i] = args[i].getClass();
             }
             // 먼저 argTypes를 전송
             out.writeObject(argTypes);
             // 그 다음 args를 전송
             out.writeObject(args);
         } else {
             //타입과 값이 없음을 나타내기 위해 null 전송
        	 out.writeObject(new Class<?>[0]);
             out.writeObject(new Object[0]);
         }

            System.out.println("스텁이 서버로 보낸 메시지: " + objectName + " " + methodName);

            in = new ObjectInputStream(socket.getInputStream());

            // 서버로부터 응답 받기
            Object response2 = in.readObject();
            if (response2 != null) {
                response = response2.toString();
            }
            System.out.println("서버로부터 받은 응답: " + response);

            socket.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return "";
    }
}
