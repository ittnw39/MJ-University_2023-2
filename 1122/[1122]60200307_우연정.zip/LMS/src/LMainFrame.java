import java.awt.BorderLayout;
import java.awt.LayoutManager;

import javax.swing.JFrame;

public class LMainFrame extends JFrame {
	private static final long serialVersionUID = 1L;

	//components
	private LMenuBar menuBar; //1.이름 지어주기
	private LMainPanel mainPanel;
	private LDirectoryPanel directoryPanel;;
	
	public LMainFrame() {
		this.setSize(600,600); // 3.속성 값 주기 - 우리만의 프레임 만들기 (상속)

		//여기에 레이아웃 매니저를 쓰는 이유는 자식이 아니라 자식을 관리하는 관리자이기 때문이다.
		
		LayoutManager layoutManager = new BorderLayout();
		this.setLayout(layoutManager); //플로우 레이아웃을 메니저로 등록.
		//자식을 확장하는 것, 추가하는 것
		this.menuBar = new LMenuBar();
		this.add(this.menuBar, BorderLayout.NORTH); //2.자식으로 등록
		
		this.mainPanel = new LMainPanel();
		this.add(this.mainPanel, BorderLayout.CENTER); //2.자식으로 등록
		
		this.directoryPanel = new LDirectoryPanel();
		this.add(this.directoryPanel, BorderLayout.WEST); //2.자식으로 등록
	}
	public void initialize() {
	}

}
