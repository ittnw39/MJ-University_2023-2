import java.awt.Color;

import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class LDirectoryPanel extends JPanel {
	private static final long serialVersionUID = 1L;

	public LDirectoryPanel() {
	    this.setBackground(Color.LIGHT_GRAY);

        // 리스트에 들어갈 항목들
        String[] items = {"용인", "서울"};

        // JList 생성
        JList<String> list = new JList<>(items);

        // 스크롤 가능하도록 JScrollPane에 JList 추가
        JScrollPane scrollPane = new JScrollPane(list);

        // JScrollPane를 패널에 추가
        this.add(scrollPane);
	}

}
