import java.awt.Color;

import javax.swing.JPanel;

public class LMainPanel extends JPanel {
	private static final long serialVersionUID = 1L;

	public LMainPanel() {
		this.setBackground(Color.blue);
	}
}
