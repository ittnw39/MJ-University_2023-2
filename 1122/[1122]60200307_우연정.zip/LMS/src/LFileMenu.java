import javax.swing.JMenu;

public class LFileMenu extends JMenu {
	private static final long serialVersionUID = 1L;

	public LFileMenu() {
		super("file");
	}

}
